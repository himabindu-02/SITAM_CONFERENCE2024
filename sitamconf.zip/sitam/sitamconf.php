<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICCETSEM 2025</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* General styles */
body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    background-color: #ffffff;
    background-image: cover;
    width: 100%;
    height: 100%;
    background-size: cover;
    background-position: center;
}
header {
  background-color: #1b6dc1;
  padding: 20px;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo-left {
  width: 100px; /* Adjust the size of both logos */
  height: 100px; /* Make sure the height is equal to the width */
  border-radius: 50%; /* This makes the logo round */
  object-fit: cover; /* Ensures the logo fits well inside the circle */
}
.logo-right {
  width: 100px; /* Adjust the size of both logos */
  height: 100px; /* Make sure the height is equal to the width */
  border-radius: 20%; /* This makes the logo round */
  object-fit: cover; /* Ensures the logo fits well inside the circle */
}

h1 {
  text-align: center;
  flex-grow: 1; /* This allows the title to grow and push the logos to the sides */
}



/* Navigation */
nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    justify-content: center;
    background-color: #1b6dc1;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

nav ul li {
    margin: 0 15px;
}

nav ul li a {
    color: white;
    text-decoration: none;
    font-size: 18px;
    padding: 15px;
    transition: background-color 0.3s ease;
}

nav ul li a:hover {
    background-color: #00467f;
    border-radius: 5px;
}
.conference-info {
    position: relative;
    overflow: hidden;
    height: 100vh; /* You can adjust this based on your desired section height */
    display: flex;
    justify-content: center;
    align-items: center;
    color: white;
    text-align: center;
    background: rgba(0, 0, 0, 0.6); /* Optional: Darken background */
}

/* Background Video Styling */
.video-wrapper {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    z-index: -1; /* Make sure video stays in the background */
}

.video-wrapper video {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

.conference-info h2 {
    font-size: 28px;
    margin-bottom: 10px;
    color: #ffd700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
}

.conference-info h3 {
    font-size: 26px;
    font-weight: bold;
    margin-bottom: 30px;
    text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.4);
}

.conference-details {
    margin: 30px 0;
}

.event-name span {
    background-color: #c18285d8;
    padding: 10px;
    border-radius: 5px;
    font-size: 24px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s ease;
}

.event-name span:hover {
    transform: scale(1.05);
}

.event-date span {
    background-color: #bfa972d8;
    padding: 10px;
    border-radius: 5px;
    font-size: 18px;
    margin-top: 15px;
    display: inline-block;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s ease;
}

.event-date span:hover {
    transform: scale(1.05);
}

.conference-info h4, .conference-info h5 {
    font-size: 18px;
    color: #e0e0e0;
    font-weight: 400;
}

.about {
    background-color: #ffffff;
    padding: 20px;
    margin: 20px auto;
    width: 90%;
    max-width: 1200px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
}

.about-container {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    flex: 1;
}

.about-info {
    width: 60%;
    background-color: #f4f4f4;
    border-radius: 10px;
    margin-right: 20px;
    padding: 50px;
}

.about-info h2 {
    background-color: #6a1b9a;
    color: #ffd700;;
    padding: 10px;
    border-radius: 5px;
}

.about-info p {
    font-size: 16px;
    line-height: 1.6;
    color: #333;
}

/* vison and mission collection */
.vison-flex{
    display: flex;
    justify-content: center;
    align-items: flex-end;
    width: 60vh;
    height: 50vh;
    padding: left 100px;;
    margin: 5px;
    background: rgba(0, 0, 0, 0.6);
}
.vision{
    text-align: center;
    width: 70%;
    padding: 100px;
    background:url("assets/imgs/college.jpg");
    border-radius: 10px;
    margin-right: 30px;
    }
.vision h2{
        color: #ffffff;
        justify-content: center;
        align-content: center;
        font-weight: bolder;
    }
.vision p{
    font-weight: bold;
    color:#ffffff; 
    justify-content: center;
    align-content: center;
}
.ab-container {
    display: flex;
    max-width: 1200px;
    margin: 0 auto;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.about-conference {
    flex: 2;
    padding: 20px;
    background-color: #f8f8ff;
}

.about-conference h2 {
    background-color: #4b2c7d;
    color: white;
    padding: 10px;
    border-radius: 4px;
}

.about-conference p {
    margin-top: 15px;
    line-height: 1.6;
    color: #333;
}

/* Location Map Section */
.location-map {
    margin: 40px auto;
    text-align: center;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    max-width: 1200px;
}

.location-map h3 {
    background-color: #6a1b9a;
    color: #ffd700;;
    padding: 10px;
    border-radius: 5px;
}

.map-container {
    margin-top: 20px;
    display: flex;
    justify-content: center;
}

.con-container {
    max-width: 1200px;
    margin: 20px auto; /* Center horizontally */
    padding: 0px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    width: 60%;
}


        .header {
            background-color: #6a1b9a;
            width: 100%;
            text-align: center;
            padding: 20px 0;
        }

        .header h1 {
            margin: 0;
            color: #ffd700;;
        }

        .con-content {
            display: flex;
            justify-content: space-between;
            width: 100%;
            max-width: 1200px;
        }

        .main-content, .sidebar {
            background-color: white;
            padding: 50px;
            box-shadow: 0 0 10px rgba(240, 236, 236, 0.1);
            color: black;
        }

        .main-content {
            flex: 3;
            margin-right: 50px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        td {
            border: 2px solid #000;
            padding: 10px;
            text-align: center;
        }

        td:hover {
            background-color: #f0f0f0;
        }

        .sidebar {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        h2, h3 {
            color: #ffd700;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        ul li {
            margin: 10px 0;
        }

        ul li a {
            text-decoration: none;
            color: black;
        }

        ul li a:hover {
            text-decoration: underline;
        }

        .sidebar ul {
            margin-top: 20px;
        }

        .sidebar ul li {
            margin: 5px 0;
        }

        .sidebar ul li a {
            display: block;
            padding: 10px;
            background-color: #ccc;
            border-radius: 5px;
            color: #333;
        }
      
        .committee-title {
            background-color: #6a1b9a;
            width: 100%;
    text-align: center;
    margin-bottom: 20px;
}
.committee-title h2{
    color: #ffd700;
}

.committee-table {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
}

.column {
    width: 30%;
    background-color: #f9f9f9;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.column h3 {
    background-color: #0056b3;
    color: white;
    padding: 10px;
    border-radius: 5px;
    text-align: center;
}

.column p {
    margin: 15px 0;
    line-height: 1.5;
}

@media (max-width: 768px) {
    .committee-table {
        flex-direction: column;
    }
    
    .column {
        width: 100%;
        margin-bottom: 15px;
    }
}
.flex-container {
    display: flex;
    justify-content: space-between; /* Optional: adjusts spacing between containers */
    gap: 20px; /* Optional: space between containers */
}

.container-left, .container-right {
    flex: 1; /* Make containers take equal space */
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Optional: adds shadow for visual appeal */
    border-radius: 8px; /* Optional: rounds the corners */
    background-color: #f4f4f4; /* Optional: background color */
}

.container-left {
    background-color: #e0f7fa;
    /* Different color for differentiation */
}
.container-left h2 {
    color: #ffd700;
    background-color: #6a1b9a;
    height: 5vh;
    text-align: center;
    padding-top: 2%;

    /* Different color for differentiation */
}

.container-right {
    background-color: #fce4ec; /* Different color for differentiation */
}

.container-right h2 {
    color: #ffd700;
    background-color: #6a1b9a;
    height: 5vh;
    text-align: center;
    padding-top: 2%;

    /* Different color for differentiation */
}
.conten {
    width: 1150px;
    padding: 75px 170px;
    display: flex; 
    justify-content: space-between;
    gap: 1.5rem; 
    align-items: center;
    cursor: pointer;
  }

.center-text{
    text-align: center;
    line-height: -5.2;
}

.center-text h5{
    color: var(--main-color);
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 1px;
    margin-bottom: 20px;
}
.center-text h5{
    color: black;
    font-size: 45px;
    font-weight: 600;
    letter-spacing: 1px;
    margin-bottom: 20px;
}

.center-text h2{
    font-size: 40px;
    line-height: -5.2;
  }

  .reg-container {
    max-width: 1200px;
    margin: 40px auto;
    padding: 20px;
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.section-title {
    text-align: center;
    margin-bottom: 20px;
    font-size: 28px;
    color: #0056b3;
}

.info-section {
    display: flex;
    justify-content: space-between;
    gap: 20px;
}

.card {
    flex: 1;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.card h3 {
    margin-bottom: 20px;
    font-size: 18px;
    color: #fff;
    padding: 10px;
    border-radius: 5px;
}

.important-dates h3 {
    background-color: #800080;
}

.payment-details h3 {
    background-color: #000080;
}

.qr-code h3 {
    background-color: #FF4500;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 12px;
    text-align: left;
}

th {
    background-color: #f4f4f4;
}

.highlight {
    background-color: #0d6efd;
    color: white;
}

.qr-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-top: 20px;
}

.qr-image {
    width: 150px;
    height: 150px;
}

.btn-register {
    margin-top: 10px;
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.btn-register:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .info-section {
        flex-direction: column;
    }

    .card {
        margin-bottom: 20px;
    }
}
.guidelines, .program-chair {
    background-color: #fff;
    border-radius: 10px;
    padding: 20px;
    width: 645px; /* Adjust width as needed */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    justify-content: space-between;
    gap: 150px;
    margin: 10px; 
    display: inline-block; /* Ensure they are inline */
    vertical-align: top; /* Align them at the top */
}

.guidelines {
    background-color: #f5f5f5;
}

.program-chair {
    background-color: #e8f4f9;
}

h2 {
    font-size: 18px;
    margin-bottom: 10px;
    color: #0056b3;
}

ul {
    list-style-type: none;
}

.guidelines ul li, .program-chair ul li {
    margin: 10px 0;
    font-size: 16px;
}

.program-chair ul li span {
    display: block;
    margin-top: 5px;
    font-size: 14px;
    color: #007bff;
}
.cta {
    display: ruby-base-container;
    align-items: center;
    gap: 1.8rem;
    padding: 20px 15px;
    transition: all 0.4s ease;
  }
  
  .cta img {
    width: 330px;
    cursor: pointer;
  }

  /* Footer Styling */
  .footer {
    background: linear-gradient(to bottom right, #287ec7, #5bb1f0);
    color: white;
    padding: 40px 0;
  }

  .footer-container {
    display: flex;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
  }

  .footer-column {
    flex: 1;
    margin-right: 20px;
  }

  .footer-column h3 {
    font-size: 20px;
    margin-bottom: 10px;
  }

  .footer-column ul {
    list-style: none;
    padding: 0;
  }

  .footer-column ul li {
    margin-bottom: 10px;
  }

  .footer-column ul li a {
    color: white;
    text-decoration: none;
  }

  .footer-column ul li a:hover {
    text-decoration: underline;
  }

  .footer-column p {
    color: white;
    line-height: 1.5;
  }

  /* Map and Address Section */
  .map {
    margin-bottom: 20px;
  }

  /* Footer Bottom */
  .footer-bottom {
    text-align: center;
    padding: 20px 0;
    font-size: 14px;
    background-color: #003d6b;
    color: white;
  }
    </style>
</head>
<body>
    <!-- Header section -->
    <header>
  <div class="header-content">
    <img src="assets/imgs/logo.jpeg" alt="Left Logo" class="logo-left">
    <h1>S I T A M - 2024</h1>
    <img src="assets/imgs/blogo.png" alt="Right Logo" class="logo-right">
  </div>
</header>


    <!-- Navigation -->
    <nav>
        <ul>
            <li><a href="#home">HOME</a></li>
            <li><a href="#about us">ABOUT US</a></li>
            <li><a href="#conference">CONFERENCE</a></li>
            <li><a href="#committee">COMMITTEE</a></li>
            <li><a href="#abstract">ABSTRACT</a></li>
            <li><a href="#registration">REGISTRATION</a></li>
            <li><a href="#placements">PLACEMENTS</a></li>
            <li><a href="#contact us">CONTACT US</a></li>
        </ul>
    </nav>

    <!-- Main Content Section -->
    <section class="conference-info" >
    <div class="video-wrapper">
            <video autoplay muted loop>
                <source src="assets/imgs/sitam.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
        <div class="content">
            <h2>ALL ACCEPTED AND REGISTERED PAPERS ARE INDEXED IN</h2>
            <div class="conference-details">
            <img src="assets/imgs/wos.jpg" alt="Left Logo" class="logo-left">
            </div>
            <p>Organized by</p>
            <h4>Satya Institute Of Engineering & Management, Gajularega,Andhra Pradesh, India</h4>
            <p>In Association with:</p>
            <h5>Bentham Science </h5>
            <a href="https://docs.google.com/forms/d/e/1FAIpQLSfpAeI5b-0hHeiWsSM9FjDVkMgL5nB3wAMP0Y8zYUwF8TNOVg/viewform?usp=pp_url"><button class="btn-register">Register Now</button></a>
        </div>
    </section>
    <br>
    <br>
    <section>
        <div class="about-container" id="about us">
            <div class="about-info">
                <h2>About SITAM</h2>
                <p>
                    JDCOEM is the educational venture of Goyal Group of Industries, Nagpur. Goyal Group is the name to reckon with in the manufacturing of Lustrous Carbon Additives, Coal Dust, Caburizers, Coatings & Bentonite. 
                    J D College of Engineering & Management is one of the leading Engineering and Technology Institutes in the region committed to the cause of quality technical and management education at diploma, Undergraduate, Post Graduate and Doctoral degree.
                </p>
                <p>
                    JDCOEM truly upholds the value of quality education and so is our tagline, "Education to Eternity".
                </p>
            </div>
                        <!-- product col left -->
                        <div class = "vision-flex">
                            <div class = "vision">
                                <h2 class = "sm-title">MOTO</h2>
                                <p class = "text-light" >To be a center of excellence imparting professional education satisfying societal and global needs.</p>
                                <br>
                                <h2 class = "sm-title">VISION</h2>
                                <p class = "text-light" >To evove into and sustain as a centre of Exeellence in Technological Education and Research with a holistie approach</p>
                                <br>
                                <h2 class = "sm-title">MISSION</h2>
                                <p class = "text-light" >To produce high quality engineering graduates with the requisite theoretical and practical knowledge and social awareness to be able to contribute effectively to the progress of the socier Erough their chosen field of endeavour</p>
                            </div>
                        </div>
    </section>

    <!-- Map Section -->
    <section class="location-map">
        <h3>SITAM Location Map / Virtual Tour</h3>
        <div class="map-container">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d237.00653214472345!2d83.40975638507676!3d18.112964184124532!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a3be5453f835edd%3A0xb5fd4425cf48c7f8!2sSitam%20Satya%20Institute%20Of%20Technology%20And%20Management!5e0!3m2!1sen!2sus!4v1727157862587!5m2!1sen!2sus"
                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </section>
    <br>
    <br>
    <section>
        <div class="ab-container" id="conference">
            <div class="about-conference">
                <h2>About Conference</h2>
                <p>In the everchanging dynamic world of technology, the fact of Permanence of change cannot be overlooked. The technology has been impacting or affecting the fortunes of corporate, policy makers and common people in several ways. The annual conference "International Conference on Cutting Edge Technologies for Science, Engineering & Management (ICCETSEM-2025)" intends to bring together the various stakeholders who are working on the various cutting edge technologies across Science, Engineering and Management disciplines so as to deliberate on identifying the potential areas wherein in cutting edge technology could pave the way for new discoveries, innovations for the benefit of mankind.</p>
                <p>On this common platform, the two days international conference will witness the enlightening and thought provoking keynote sessions, open discussion forums, panel discussions etc. The various tracks covering Artificial Intelligence, Data Science, Robotics, Sustainability, Innovations and solutions for Society 5.0, etc will provide the platform for the researchers, academicians, UG and PG students to present their research work before the national and international luminaries and also provide the opportunities to widen their network across the globe.</p>
            </div>
        
            <div class="ssidebar">
                <div class="download">
                    <h3>Download</h3>
                    <a href="#">Copyright assignment and publishing agreement BENTHAM SCIENCE Books</a>
                    <p>Brochure will be Uploaded Soon...</p>
                </div>
        
                <div class="publication-partner">
                    <h3>Publication Partner</h3>
                    <a href="#">Copyright assignment and publishing agreement BENTHAM SCIENCE Books</a>
                    <p>Brochure will be Uploaded Soon...</p>
                    <!-- Content for Publication Partner will go here -->
                </div>
            </div>
        </div>
    </section>
    <br>
    <br>
    <section>
    <div class="con-container" id="committee">
        <div class="header">
            <h1>Committee</h1>
        </div>

        <div class="con-content">
            <div class="main-content">
                <h2>Advisory  Committee</h2>
                <table>
                    <tr>
                        <td>Dr. Bui Thanh Hung<br><small>Industrial University of Ho Chi Minh City -Iuh, Vietnam</small></td>
                        <td>Dr. Bui Thanh Hung<br><small>Industrial University of Ho Chi Minh City -Iuh, Vietnam</small></td>
                        <td>Dr. Bui Thanh Hung<br><small>Industrial University of Ho Chi Minh City -Iuh, Vietnam</small></td>
                    </tr>
                    <tr>
                        <td>Keynote Speech: The Future of Clean Energy</td>
                        <td>10:15 AM - 11:00 AM</td>
                        <td>qwertyuiop</td>
                    </tr>
                    <tr>
                        <td>Panel Discussion: Sustainable Development Goals</td>
                        <td>11:15 AM - 12:30 PM</td>
                        <td>qwertyuiop</td>
                    </tr>
                    <tr>
                        <td>Lunch Break</td>
                        <td>12:30 PM - 01:30 PM</td>
                        <td>qwertyuiop</td>
                    </tr>
                    <tr>
                        <td>Technical Session: Emerging Technologies</td>
                        <td>01:45 PM - 03:15 PM</td>
                        <td>qwertyuiop</td>
                    </tr>
                    <tr>
                        <td>Keynote Speech: The Future of Clean Energy</td>
                        <td>10:15 AM - 11:00 AM</td>
                        <td>qwertyuiop</td>
                    </tr>
                    <tr>
                        <td>Panel Discussion: Sustainable Development Goals</td>
                        <td>11:15 AM - 12:30 PM</td>
                        <td>qwertyuiop</td>
                    </tr>
                    <tr>
                        <td>Lunch Break</td>
                        <td>12:30 PM - 01:30 PM</td>
                        <td>qwertyuiop</td>
                    </tr>
                    <tr>
                        <td>Technical Session: Emerging Technologies</td>
                        <td>01:45 PM - 03:15 PM</td>
                        <td>qwertyuiop</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="con-container">
        <div class="committee-title">
            <h2>Conference Committee</h2>
        </div>
        <div class="committee-table">
            <div class="column">
                <h3>General Chair</h3>
                <p>Dr. Shrikant Sonekar<br>Principal, JDCOEM</p>
            </div>
            <div class="column">
                <h3>Treasurer</h3>
                <p>Dr. Ujwala Dange</p>
            </div>
            <div class="column">
                <h3>Organizing Committee</h3>
                <p>Dr. Ghanshyam Nikhade<br>Dr. Rohit Patne<br>Dr. Manoj Rao<br>Prof. Rahul Nawkare<br>Prof. Nilesh Panchbudhe<br>Prof. Mandar Issare<br>Prof. Rajendra Dhandre<br>Prof. Rasika Samrit</p>
            </div>
            <div class="column">
                <h3>Organizing Committee</h3>
                <p>Dr. Ghanshyam Nikhade<br>Dr. Rohit Patne<br>Dr. Manoj Rao<br>Prof. Rahul Nawkare<br>Prof. Nilesh Panchbudhe<br>Prof. Mandar Issare<br>Prof. Rajendra Dhandre<br>Prof. Rasika Samrit</p>
            </div>
            <div class="column">
                <h3>Organizing Committee</h3>
                <p>Dr. Ghanshyam Nikhade<br>Dr. Rohit Patne<br>Dr. Manoj Rao<br>Prof. Rahul Nawkare<br>Prof. Nilesh Panchbudhe<br>Prof. Mandar Issare<br>Prof. Rajendra Dhandre<br>Prof. Rasika Samrit</p>
            </div>
        </div>
    </div>
<div class="flex-container" id="abstract">
    <div class="container-left">
        <h2>ABSTRACT</h2>
        <p>In the everchanging dynamic world of technology, the fact of Permanence of change cannot be overlooked. The technology has been impacting or affecting the fortunes of corporate, policy makers and common people in several ways. The annual conference "International Conference on Cutting Edge Technologies for Science, Engineering & Management (ICCETSEM-2025)"intends to bring together the various stakeholders who are working on the various cutting edge technologies across Science, Engineering and Management disciplines so as to deliberate on identifying the potential areas wherein in cutting edge technology could pave the way for new discoveries, innovations for the benefit of mankind.

            On this common platform, the two days international conference will witness the enlightening and thought provoking keynote sessions, open discussion forums, panel discussions etc. The various tracks covering Artificial Intelligence, Data Science, Robotics, Sustainability, Innovations and solutions for Society 5.0, etc will provide the platform to the researchers, academicians, UG and PG students to present their research work before the national and international luminaries and also provide the opportunities to widen their network across the globe..</p>
    </div>
    <div class="container-right">
        <h2>CALL FOR PAPER</h2>
        <p>In the everchanging dynamic world of technology, the fact of Permanence of change cannot be overlooked. The technology has been impacting or affecting the fortunes of corporate, policy makers and common people in several ways. The annual conference "International Conference on Cutting Edge Technologies for Science, Engineering & Management (ICCETSEM-2025)"intends to bring together the various stakeholders who are working on the various cutting edge technologies across Science, Engineering and Management disciplines so as to deliberate on identifying the potential areas wherein in cutting edge technology could pave the way for new discoveries, innovations for the benefit of mankind.

            On this common platform, the two days international conference will witness the enlightening and thought provoking keynote sessions, open discussion forums, panel discussions etc. The various tracks covering Artificial Intelligence, Data Science, Robotics, Sustainability, Innovations and solutions for Society 5.0, etc will provide the platform to the researchers, academicians, UG and PG students to present their research work before the national and international luminaries and also provide the opportunities to widen their network across the globe.</p><a href="guide.docx">Click Here</a>
    </div>
</div>
</section>
<br>
<br>
<section>
<div class="reg-container" id="registration">
    <h2 class="section-title">Registration Details</h2>
    
    <div class="info-section">
        <!-- Important Dates -->
        <div class="card important-dates">
            <h3><i class="fa fa-calendar"></i> Important Dates</h3>
            <table>
                <tr>
                    <th>Event</th>
                    <th>Date</th>
                </tr>
                <tr>
                    <td>Full Length Chapter Submission</td>
                    <td >Oct 15, 2024</td>
                </tr>
                <tr>
                    <td>Acceptance Notification</td>
                    <td>Nov 15, 2024</td>
                </tr>
                <tr>
                    <td>Last Date of Registration</td>
                    <td>Nov 25, 2024</td>
                </tr>
                <tr>
                    <td>Camera Ready Submission</td>
                    <td>Dec 5, 2024</td>
                </tr>
                <tr>
                    <td>Conference Dates</td>
                    <td>Jan 10-11, 2025</td>
                </tr>
                <tr>
                    <td>Last Date of Registration</td>
                    <td>Nov 25-28, 2024</td>
                </tr>
            </table>
        </div>
        
        <!-- Payment Details -->
        <div class="card payment-details">
            <h3><i class="fa fa-credit-card"></i> Payment Details</h3>
            <table>
                <tr>
                    <th>Category</th>
                    <th>Amount</th>
                </tr>
                <tr>
                    <td>UG Students</td>
                    <td>Rs. 8000/-</td>
                </tr>
                <tr>
                    <td>PG Students</td>
                    <td>Rs. 8500/-</td>
                </tr>
                <tr>
                    <td>Ph.D./Research Scholar</td>
                    <td>Rs. 9000/-</td>
                </tr>
                <tr>
                    <td>Academician</td>
                    <td>Rs. 9500/-</td>
                </tr>
                <tr>
                    <td>Industrialist</td>
                    <td>Rs. 10000/-</td>
                </tr>
                <tr>
                    <td>Delegate</td>
                    <td>Rs. 2000/-</td>
                </tr>
                <tr>
                    <td>Foreign Authors</td>
                    <td>$ 120 USD</td>
                </tr>
            </table>
        </div>
        
        <!-- QR Code -->
        <div class="card qr-code">
            <h3><i class="fa fa-user"></i> Registration</h3>
            <div class="qr-container">
                <br>
                <br>
                <br>
                <br>
                <img src="assets/imgs/qr.png" alt="QR Code" class="qr-image">
                <a href="https://docs.google.com/forms/d/e/1FAIpQLSfpAeI5b-0hHeiWsSM9FjDVkMgL5nB3wAMP0Y8zYUwF8TNOVg/viewform?usp=pp_url"><button class="btn-register">Register Now</button></a>
            </div>
        </div>
    </div>
</div>
</section>
<br>
<br>
<section>
   
    <div class="guidelines">
        <h2>Guidelines for Chapter/Paper Submission</h2>
        <ul>
            <li>Maximum 6 pages will be allowed per Book chapter/ Paper.</li>
            <li>Certificates will be provided to all the authors.</li>
            <li>Participation certificate will be given to all delegates.</li>
            <li>Rs. 1000/ 12 USD extra to be paid per page, if the number of pages is more than 6.</li>
            <li>15% plagiarism will be allowed only.</li>
            <li>Submission of paper should be in proper template.</li>
            <li>Registration kit will be provided to the author presenting the paper.</li>
            <li>Additional kit includes breakfast, lunch, High Tea and certificates on payment of Rs. 1500.</li>
            <br>
        </ul>
    </div>

    <div class="program-chair" id="program chair">
        <h2>Program Chair</h2>
        <ul>
            <li>Dr. Vaishnavi Dhok <span>8983388156</span></li>
            <li>Dr. Bhavna Ilamkar <span>8275272067</span></li>
            <li>Dr. Atika Ingole <span>9096828931</span></li>
            <li>Dr. Parvin Shaikh <span>7888018363</span></li>
            <li>Dr. Parvin Shaikh <span>7888018363</span></li>
        </ul>
    </div>
    <section class="cta" id="placements">
        <div class="center-text">
            <h5>SPONSORS</h5>
        </div>
        <section class="conten">
        <div class="cta-content">
            <div class="">
                <img src="assets/imgs/wos.jpg">
            </div>
        </div>
        <div class="cta-content">
            <div class="">
                <img src="assets/imgs/wos.jpg">
            </div>
        </div>
        <div class="cta-content">
            <div class="">
                <img src="assets/imgs/wos.jpg">
            </div>
        </div>
    </section>
</section>

</section>
    <section class="cta" id="placements">
        <div class="center-text">
            <h5>Placements Record</h5>
            <h2>500+ Global Corporates from 2022 to 2025</h2>
        </div>
        <section class="conten">
        <div class="cta-content">
            <div class="">
                <img src="assets/imgs/brand.jpg">
            </div>
        </div>
        <div class="cta-content">
            <div class="">
                <img src="assets/imgs/brand2.jpg">
            </div>
        </div>
        <div class="cta-content">
            <div class="">
                <img src="assets/imgs/brand3.jpg">
            </div>
        </div>
    </section>
</section>
<!-- Footer Section -->
<footer class="footer" id="contact us">
    <div class="footer-container">

      <!-- About the Conference Column -->
      <div class="footer-column">
        <h3>About the Conference</h3>
        <ul>
          <li><a href="#about us">About Us</a></li>
          <li><a href="#conference">Conference Overview</a></li>
          <li><a href="#committie">Keynote Speakers</a></li>
          <li><a href="#home">Important Dates</a></li>
        </ul>
      </div>

      <!-- Registration Column -->
      <div class="footer-column">
        <h3>Registration</h3>
        <ul>
          <li><a href="#registration">Register Now</a></li>
          <li><a href="#registration">Registration Fees</a></li>
          <li><a href="#registration">Accommodation</a></li>
          <li><a href="#registration">Travel Information</a></li>
        </ul>
      </div>

      <!-- Quick Links Column -->
      <div class="footer-column">
        <h3>Quick Links</h3>
        <ul>
          <li><a href="#home">Home</a></li>
          <li><a href="#home">Contact Us</a></li>
          <li><a href="#home">FAQ</a></li>
          <li><a href="#program chair">Sponsors</a></li>
          <li><a href="#home">About Nagpur</a></li>
        </ul>
      </div>

      <!-- Find Us Column with Map -->
      <div class="footer-column">
        <h3>Find Us</h3>
        <div class="map">
          <!-- You can replace the iframe with the actual map embed link -->
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d237.00653214472345!2d83.40975638507676!3d18.112964184124532!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a3be5453f835edd%3A0xb5fd4425cf48c7f8!2sSitam%20Satya%20Institute%20Of%20Technology%20And%20Management!5e0!3m2!1sen!2sus!4v1727157862587!5m2!1sen!2sus"
            width="200" height="150" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
        <p><strong>Address:</strong><br>
          S I T A M<br>
          Satya Institute of Technology and Management <br>
          At: Gajularega, Kondakarakam (P.O)<br>
          Vizianagaram,<br>
          Andhra Pradesh, INDIA - 535003
        </p>
      </div>

    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">
      <p>&copy; 2024 J D College of Engineering & Management, Nagpur, MH, India. All rights reserved.</p>
    </div>
  </footer>

</body>
</html>